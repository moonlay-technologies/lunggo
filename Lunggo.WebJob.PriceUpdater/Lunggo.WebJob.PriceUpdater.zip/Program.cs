﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lunggo.WebJob.PriceUpdater
{
    partial class Program
    {
        static void Main()
        {
            Init();
            var todaydate = DateTime.Now;
            var endofmonth = DateTime.DaysInMonth(todaydate.Year, todaydate.Month);
            var difference = endofmonth - todaydate.Day;
            for (var i = 0; i <= difference; i++)
            {
                FlightPriceUpdater("JKT", "DPS", todaydate.AddDays(i));
                FlightPriceUpdater("JKT", "JOG", todaydate.AddDays(i));
                FlightPriceUpdater("JKT", "KUL", todaydate.AddDays(i));
                FlightPriceUpdater("JKT", "SIN", todaydate.AddDays(i));
                FlightPriceUpdater("JKT", "DPS", todaydate.AddDays(i));
                FlightPriceUpdater("JKT", "HKG", todaydate.AddDays(i));
                FlightPriceUpdater("JKT", "SUB", todaydate.AddDays(i));
                FlightPriceUpdater("JKT", "SIN", todaydate.AddDays(i));
                FlightPriceUpdater("DPS", "JKT", todaydate.AddDays(i));
            }
            
        }
    }
}
